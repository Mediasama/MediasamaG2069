Define.RANK_ALL_ID = 1
Define.RANK_GLOBAL_ID = 2
Define.RANK_ROOM_ID = 3
--Define.RANK_FRIEND_ID = 2

Define.RANK_REFRESH_TIME = 2
--Define.RANK_MAX_NUM = 200

Define.RANK_PAGE_SIZE = 10 -- 一页的人数
Define.RANK_DELETE_SINGLE_CACHE_TIME = 1 -- 删除个人缓存时间（单位：分钟）
Define.RANK_REQUEST_CD = 0 -- 每次向平台请求数据的时间间隔（单位：秒）
Define.REQUEST_INTERVAL = 1200 -- 服务器每隔x的tick，向平台请求新的排行数据（单位：帧）