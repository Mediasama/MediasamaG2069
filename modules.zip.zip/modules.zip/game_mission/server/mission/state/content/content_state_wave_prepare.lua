--- 准备状态

---@class ContentStateWavePrepare : StageContentBase
local ContentStateWavePrepare = {}

function ContentStateWavePrepare:enteredState()
end

--- 心跳函数，间隔每秒
function ContentStateWavePrepare:onUpdate()
end

function ContentStateWavePrepare:exitedState()
end

return ContentStateWavePrepare