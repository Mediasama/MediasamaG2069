--- 结束状态

---@class ContentStateWaveEnd : StageContentBase
local ContentStateWaveEnd = {}

function ContentStateWaveEnd:enteredState()
end

--- 心跳函数，间隔每秒
function ContentStateWaveEnd:onUpdate()
end

function ContentStateWaveEnd:exitedState()
end

return ContentStateWaveEnd