--- 准备状态

---@class StageStateStagePrepare : MissionStage
local StageStateStagePrepare = {}

function StageStateStagePrepare:enteredState()
end

--- 心跳函数，间隔每秒
function StageStateStagePrepare:onUpdate()
end

function StageStateStagePrepare:exitedState()
end

return StageStateStagePrepare